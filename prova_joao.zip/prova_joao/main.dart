import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class Pokemon {
  final String name;
  final String imageUrl;

  Pokemon({required this.name, required this.imageUrl});
}

class Generation {
  final String title;
  final List<String> pokemons;

  Generation({required this.title, required this.pokemons});
}

const List<Generation> generations = [
  Generation(
    title: 'Generation I',
    pokemons: [
      'assets/images/bulbasaur.png',
      'assets/images/charmander.png',
      'assets/images/squirtle.png',
    ],
  ),
  Generation(
    title: 'Generation II',
    pokemons: [
      'assets/images/chikorita.png',
      'assets/images/cyndaquil.png',
      'assets/images/totodile.png',
    ],
  ),
  Generation(
    title: 'Generation III',
    pokemons: [
      'assets/images/treecko.png',
      'assets/images/torchic.png',
      'assets/images/mudkip.png',
    ],
  ),
Generation(
    title: 'Generation IV',
    pokemons: [
      'assets/images/turtwig.png',
      'assets/images/chimchar.png',
      'assets/images/piplup.png'
    ],
  ),
  Generation(
    title: 'Generation V',
    pokemons: [
      'assets/images/snivy.png',
      'assets/images/tepig.png',
      'assets/images/oshawott.png'
    ],
  ),
  Generation(
    title: 'Generation VI',
    pokemons: [
      'assets/images/chespin.png',
      'assets/images/fennekin.png',
      'assets/images/froakie.png'
    ],
  ),
  Generation(
    title: 'Generation VII',
    pokemons: [
      'assets/images/rowlet.png',
      'assets/images/litten.png',
      'assets/images/popplio.png'
    ],
  ),
  Generation(
    title: 'Generation VIII',
    pokemons: [
      'assets/images/grookey.png',
      'assets/images/scorbunny.png',
      'assets/images/sobble.png'
    ],
  ),
];

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pokémon App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: PokemonList(),
    );
  }
}

class PokemonList extends StatefulWidget {
  @override
  _PokemonListState createState() => _PokemonListState();
}

class _PokemonListState extends State<PokemonList> {
  List<Pokemon> pokemonList = [];

  @override
  void initState() {
    super.initState();
    fetchPokemonList();
  }

  Future<void> fetchPokemonList() async {
    for (var generation in generations) {
      for (var imageUrl in generation.pokemons) {
        setState(() {
          final pokemonName = imageUrl.split('/').last.split('.').first;
          pokemonList.add(Pokemon(name: pokemonName, imageUrl: imageUrl));
        });
      }
    }
  }

  void showPokemonDetails(Pokemon pokemon) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(pokemon.name),
          content: Image.asset(pokemon.imageUrl),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Fechar'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Lista de Pokémons'),
      ),
      body: ListView.builder(
        itemCount: pokemonList.length,
        itemBuilder: (context, index) {
          final pokemon = pokemonList[index];
          return ListTile(
            title: Text(pokemon.name),
            leading: Image.asset(pokemon.imageUrl),
            onTap: () {
              showPokemonDetails(pokemon);
            },
          );
        },
      ),
    );
  }
}